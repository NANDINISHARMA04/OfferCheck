"""Scam detection engine. Use `analyze()` as the single entry point."""
from .pipeline import analyze

__all__ = ["analyze"]
